// 5 casos de teste para as principais funcionalidades de uma DHT


#include <iostream>


class Assegurados{
private:
int IMEI; //chave de busca
std::string login;
public:
Assegurados(); //métodos construtores de alocação de memória
Assegurados(int IMEI, std::string login);

string getlogin () const;
string getIMEI () const;
};

Assegurados::Assegurados(){
  this -> IMEI = -1;
  this -> login = "";
  };

Assegurados::Assegurados(int IMEI, std::string login){
  this -> IMEI = -1;
  this -> login = "";
};


}








int main() {
  string hash = "0xe95c8248ff901763d056c603d112cfd3301dd8376feb9a8d010ab92b1557c04d\n";
  string sub = hash.substr(2, 6);

  cout << "teste: " << sub;